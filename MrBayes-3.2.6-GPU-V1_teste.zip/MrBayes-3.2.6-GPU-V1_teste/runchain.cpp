#include "kernel.h"
extern "C" {
#include "mcmc.h"
#include "likelihood.h"
#include "utils.h"
#include "model.h"
	
	void	  FlipCondLikeSpace(ModelInfo *m, int chain, int nodeIndex);
	void	  FlipCijkSpace(ModelInfo *m, int chain);
	void      FlipNodeScalerSpace(ModelInfo *m, int chain, int nodeIndex);
	void      FlipSiteScalerSpace(ModelInfo *m, int chain);
	void      FlipTiProbsSpace(ModelInfo *m, int chain, int nodeIndex);
	int		  UpDateCijk(int whichPart, int whichChain);
	void	  ResetSiteScalers(ModelInfo *m, int chain);
	void	  CopySiteScalers(ModelInfo *m, int chain);
	int		  RemoveNodeScalers(TreeNode *p, int division, int chain);
	int		  CalcLikeAdgamma(int d, Param *param, int chain, MrBFlt *lnL);
	void	  LaunchBEAGLELogLikeForDivision(int chain, int d, ModelInfo* m, Tree* tree, MrBFlt* lnL);
}

extern int *chainId;
extern int chooseModel;
extern i64 lnLikeSize;										/* the size of lnlike for each char														*/
extern CLFlt **ChainCondLikesIndex_Device;					/* store the first pointer to cond likes for each division for locating					*/
extern CLFlt **ScalerIndex_Device;							/* store the first pointer to scalers for each division for locating					*/
extern CLFlt **TiProbIndex_Device;							/* store the first pointer to tiProbs for each division for locating					*/
extern CLFlt **InvCondLikeIndex_Device;						/* store the first pointer to inv cond likes for each division for locating				*/
extern int *lnLike_Index;									/* store the index for lnLike_Device, maybe defined as i64 ?							*/
extern CLFlt *ChainCondLikes_Device;						/* space for all cond likes for all divisions: divisions * condlikes for each division	*/
extern CLFlt *Scalers_Device;								/* space for node and site scalers														*/
extern CLFlt *TiProbs_Device;								/* space for tiProbs for all divisions													*/
extern CLFlt *InvCondLikes_Device;							/* space for inv cond likes																*/
extern CLFlt **clP_Device;									/* space for clP																		*/
extern MrBFlt *lnLike_Device;								/* space for lnlike of each char														*/
extern MrBFlt *modelLnL_Device;								/* space for log like of chain : used for device only									*/
extern MrBFlt *modelLnL_Global;								/* space for log like of chain : used for host (recieve log like transfered from device)*/
extern CLFlt *numSitesOfPat_Device;							/* no. sites of each pattern															*/
extern CLFlt *preLikeL_Device;								/* precalculated cond likes for left descendant											*/
extern CLFlt *preLikeR_Device;								/* precalculated cond likes for right descendant										*/
extern CLFlt *preLikeA_Device;								/* precalculated cond likes for ancestor												*/
extern MrBFlt *stateFreq_Device;							/* space for stateFreq (also called as bs)												*/
extern MrBFlt *omegaCatFreq_Device;							/* space for category frequencies omegaCatFreq											*/



/* declaration of helper functions : rewrite RunChain and LogLike */
extern "C" int		RunChainInit();
extern "C" int		RunChainFinal();
extern "C" MrBFlt	LogLike_CUDA(int chain);

void	LaunchLogLike_TiProbs(int chain);
void	LaunchLogLike_CondLike(int chain);
MrBFlt	LaunchLogLike_LnLike(int chain);


template<int nChild>void	CondLike_Gen_CUDA(TreeNode* p, int division, int chain);
void	Scaler_Gen_CUDA(TreeNode* p, int division, int chain);
void	Likelihood_Gen_CUDA(TreeNode *p, int division, int chain, int whichSitePats);
void	Likelihood_NY98_CUDA(TreeNode *p, int division, int chain, int whichSitePats);


/* toBeTest : the addressing method for CondLike, tiProbs and Scalers */
template<int nChild> void CondLike_Gen_CUDA(TreeNode* p, int division, int chain)
{
	ModelInfo	*m;

	/* find model settings for this division and nStates, nStatesSquared */
	m = &modelSettings[division];
	
	ModelParam modelParam;
	modelParam.numChars = m->numChars;
	modelParam.numModelStates = m->numModelStates;
	modelParam.numReps = m->numOmegaCats > 1 ? m->numOmegaCats : m->numGammaCats;

	/* flip conditional likelihood space */
	FlipCondLikeSpace(m, chain, p->index);

	/* find conditional likelihood pointers and encapsulate */
	CLFlt *clP = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->index] * m->condLikeLength;
	
	CLFlt* cl[nChild];
	CLFlt* ti[nChild];

	cl[0] = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->left->index] * m->condLikeLength;
	cl[1] = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->right->index] * m->condLikeLength;

	ti[0] = TiProbIndex_Device[division] + m->tiProbsIndex[chain][p->left->index] * m->tiProbLength;
	ti[1] = TiProbIndex_Device[division] + m->tiProbsIndex[chain][p->right->index] * m->tiProbLength;

	/* call kernel function to calculate condlikes */
	if (nChild == 3)
	{
		cl[2] = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->anc->index] * m->condLikeLength;
		ti[2] = TiProbIndex_Device[division] + m->tiProbsIndex[chain][p->index] * m->tiProbLength;
		Launch_Kernel_CondLike_Gen_3(cl, ti, clP, modelParam, chain);
	}
	else
		Launch_Kernel_CondLike_Gen_2(cl, ti, clP, modelParam, chain);

}

void Scaler_Gen_CUDA(TreeNode* p, int division, int chain)
{
	ModelInfo	*m;
	CLFlt		*clPtr, *clP, *scP, *lnScaler;

	m = &modelSettings[division];

	ModelParam modelParam;
	modelParam.numChars = m->numChars;
	modelParam.numModelStates = m->numModelStates;
	modelParam.numReps = m->numOmegaCats > 1 ? m->numOmegaCats : m->numGammaCats;

	/* find conditional likelihood pointers */
	clPtr = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->index] * m->condLikeLength;
	clP = clPtr;

	/* find node scalers */
	scP = ScalerIndex_Device[division] + m->nodeScalerIndex[chain][p->index] * m->numChars;

	/* find site scalers */
	lnScaler = ScalerIndex_Device[division] + m->siteScalerIndex[chain] * m->numChars;

	/* call kernel function to rescale */
	Launch_Kernel_Scaler_Gen(clP, scP, lnScaler, modelParam, chain);

	m->scalersSet[chain][p->index] = YES;
}

void Likelihood_Gen_CUDA(TreeNode *p, int division, int chain, int whichSitePats)
{
	ModelInfo	*m;
	int			nStates, hasPInvar, j, k;
	CLFlt		*clInvar = NULL, *clP, *lnScaler, *nSitesOfPat;
	MrBFlt		*bs, *swr, *sum, covBF[40], s01, s10, probOn, probOff, freq, pInvar = 0.0, *lnL;

	/* find model settings and nStates, pInvar, invar cond likes*/
	m = &modelSettings[division];
	nStates = m->numModelStates;

	if (m->pInvar == NULL)
	{
		hasPInvar = NO;
	}
	else
	{
		hasPInvar = YES;
		pInvar = *(GetParamVals(m->pInvar, chain, state[chain]));
		clInvar = InvCondLikeIndex_Device[division];
	}

	/* find conditional likelihood pointers */
	clP = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->index] * m->condLikeLength;

	/* find base frequencies */
	bs = GetParamSubVals(m->stateFreq, chain, state[chain]);

	/* if covarion model, adjust base frequencies */
	if (m->switchRates != NULL)
	{
		/* find the stationary frequencies */
		swr = GetParamVals(m->switchRates, chain, state[chain]);
		s01 = swr[0];
		s10 = swr[1];
		probOn = s01 / (s01 + s10);
		probOff = 1.0 - probOn;

		/* now adjust the base frequencies; on-state stored first in cond likes */
		for (j = 0; j < nStates / 2; ++j)
		{
			covBF[j] = bs[j] * probOn;
			covBF[j + nStates / 2] = bs[j] * probOff;
		}

		/* finally set bs pointer to adjusted values */
		bs = covBF;
	}

	CudaMemcpyBS(bs, m->numModelStates);

	/* find category frequencies */
	freq = 1.0 / m->numGammaCats;

	/* find site scaler */
	lnScaler = ScalerIndex_Device[division] + m->siteScalerIndex[chain] * m->numChars;

	/* find nSitesOfPat*/
	nSitesOfPat = numSitesOfPat_Device + (whichSitePats*numCompressedChars) + m->compCharStart;

	/* reset lnL */
	lnL = lnLike_Device + lnLikeSize * chain + lnLike_Index[division];

	/* set log like */
	sum = modelLnL_Device + chain * numCurrentDivisions + division;

	LikelihoodInput in;
	in.bs = stateFreq_Device;
	in.clP = clP;
	in.lnScaler = lnScaler;
	in.nSitesOfPat = nSitesOfPat;

	ModelParam mp;
	mp.numChars = m->numChars;
	mp.numModelStates = m->numModelStates;
	mp.numReps = m->numGammaCats;

	/* redo : the index of sum for Kernel_Sum is not sure*/
	Launch_Kernel_Likelihood_Gen(in, clInvar, pInvar, lnL, sum, mp, chain);
}

void Likelihood_NY98_CUDA(TreeNode *p, int division, int chain, int whichSitePats)
{
	ModelInfo	*m;
	CLFlt		*clP, *lnScaler, *nSitesOfPat;
	MrBFlt		*bs, *omegaCatFreq, *lnL, *sum;
	int			nStates;

	m = &modelSettings[division];

	/* number of states */
	nStates = m->numModelStates;

	/* find conditional likelihood pointers */
	clP = ChainCondLikesIndex_Device[division] + m->condLikeIndex[chain][p->index] * m->condLikeLength;

	/* find codon frequencies */
	bs = GetParamSubVals(m->stateFreq, chain, state[chain]);
	CudaMemcpyBS(bs, m->numModelStates);

	/* find category frequencies */
	omegaCatFreq = GetParamSubVals(m->omega, chain, state[chain]);
	CudaMemcpyOmegaCatFreq(omegaCatFreq, m->numOmegaCats);

	/* find site scaler */
	lnScaler = ScalerIndex_Device[division] + m->siteScalerIndex[chain] * m->numChars;

	/* find nSitesOfPat */
	nSitesOfPat = numSitesOfPat_Device + (whichSitePats * numCompressedChars) + m->compCharStart;

	/* reset lnL */
	lnL = lnLike_Device + lnLikeSize * chain + lnLike_Index[division];

	/* set log like */
	sum = modelLnL_Device + chain * numCurrentDivisions + division;

	LikelihoodInput in;
	in.bs = stateFreq_Device;
	in.clP = clP;
	in.lnScaler = lnScaler;
	in.nSitesOfPat = nSitesOfPat;

	ModelParam mp;
	mp.numChars = m->numChars;
	mp.numModelStates = m->numModelStates;
	mp.numReps = m->numOmegaCats;

	/* redo : the index of sum for Kernel_Sum is not sure*/
	Launch_Kernel_Likelihood_NY98(in, omegaCatFreq_Device, lnL, sum, mp, chain);
}



extern "C" int RunChainInit()
{
	SetCudaEnvironment();
	
	CudaMallocAll();
	
	//transform condlikes
	//redo in cudaMallocAll()

	//set device data
	//redo in cudaMallocAll
	return NO_ERROR;
}

extern "C" int RunChainFinal()
{
	CudaFreeAll();
	return NO_ERROR;
}



void LaunchLogLike_TiProbs(int chain)
{
	int i, d;
	TreeNode        *p;
	ModelInfo       *m;
	Tree            *tree;

	/* Cycle through divisions and recalculate tis as necessary.                */
	/* Code below does not try to avoid recalculating ti probs for divisions    */
	/* that could share ti probs with other divisions.                          */
	for (d = 0; d < numCurrentDivisions; d++)
	{
		m = &modelSettings[d];
		if (m->upDateCl != YES)
			continue;

		tree = GetTree(m->brlens, chain, state[chain]);

		if (m->upDateCijk == YES && UpDateCijk(d, chain) == ERROR)
			return;

		if (m->parsModelId == NO)
		{
			for (i = 0; i < tree->nIntNodes; i++)
			{
				p = tree->intDownPass[i];

				if (p->left->upDateTi == YES)
				{
					/* shift state of ti probs for node */
					FlipTiProbsSpace(m, chain, p->left->index);
					m->TiProbs(p->left, d, chain);
					cudaMemcpyAsyncTiProbs(p->left, d, chain);
				}

				if (p->right->upDateTi == YES)
				{
					/* shift state of ti probs for node */
					FlipTiProbsSpace(m, chain, p->right->index);
					m->TiProbs(p->right, d, chain);
					cudaMemcpyAsyncTiProbs(p->right, d, chain);
				}

				if (tree->isRooted == NO)
				{
					if (p->anc->anc == NULL /* && p->upDateTi == YES */)
					{
						/* shift state of ti probs for node */
						FlipTiProbsSpace(m, chain, p->index);
						m->TiProbs(p, d, chain);
						cudaMemcpyAsyncTiProbs(p, d, chain);
					}
				}
			}
		}
	}

	//redo: TiProbs transfer from host to device, but maybe there is something wrong
	//cudaMemcpyAsyncTiProbs(chain);
}

void LaunchLogLike_CondLike(int chain)
{
	int i, d;
	TreeNode        *p;
	ModelInfo       *m;
	Tree            *tree;

	/* Cycle through divisions and recalculate cond likes as necessary.     */
	for (d = 0; d < numCurrentDivisions; d++)
	{
		m = &modelSettings[d];
		if (m->upDateCl != YES)
			continue;

		tree = GetTree(m->brlens, chain, state[chain]);

		if (m->upDateCijk == YES)
		{
			if (UpDateCijk(d, chain) == ERROR)
			{
				//(*lnL) = MRBFLT_NEG_MAX; /* effectively abort the move */
				m->lnLike[2 * chain + state[chain]] = MRBFLT_NEG_MAX;
				continue;
			}
			m->upDateAll = YES;
		}

#   if defined (BEAGLE_ENABLED)
		if (m->useBeagle == YES)
		{
			LaunchBEAGLELogLikeForDivision(chain, d, m, tree, &(m->lnLike[2 * chain + state[chain]]));
			return;
		}
#   endif

		/* Flip and copy or reset site scalers */
		FlipSiteScalerSpace(m, chain);
		if (m->upDateAll == YES)
			cudaResetSiteScalers(d, m, chain);
		else
			cudaCopySiteScalers(d, m, chain);

		if (m->parsModelId == NO)
		{
			for (i = 0; i<tree->nIntNodes; i++)
			{
				p = tree->intDownPass[i];
				if (p->upDateCl == YES)
				{
					if (tree->isRooted == NO)
					{
						if (p->anc->anc == NULL)
						{
							CondLike_Gen_CUDA<3> (p, d, chain);
						}
						else
						{
							CondLike_Gen_CUDA<2>(p, d, chain);
						}
					}
					else
					{
						CondLike_Gen_CUDA<2>(p, d, chain);
					}

					if (m->scalersSet[chain][p->index] == YES && m->upDateAll == NO)
					{
						//TIME(RemoveNodeScalers(p, d, chain), CPUScalersRemove);
						cudaRemoveNodeScalers(p, d, chain);
					}
					FlipNodeScalerSpace(m, chain, p->index);
					m->scalersSet[chain][p->index] = NO;

					if (p->scalerNode == YES)
					{
						Scaler_Gen_CUDA(p, d, chain);
					}
				}
			}
		}
		//call function of Likelihood-calculating on GPU 
		if (chooseModel == 1)
			Likelihood_Gen_CUDA(tree->root->left, d, chain, (chainId[chain] % chainParams.numChains));
		else
			Likelihood_NY98_CUDA(tree->root->left, d, chain, (chainId[chain] % chainParams.numChains));
	}

	//redo: modelLnL transfer from device to host
	cudaMemcpyAsyncModelLnL(chain);
}

MrBFlt LaunchLogLike_LnLike(int chain)
{
	int             i, d;
	ModelInfo       *m;
	MrBFlt          chainLnLike;

	/* initialize chain cond like */
	chainLnLike = 0.0;

	if (abortMove == YES)
		return MRBFLT_NEG_MAX;

	//redo: CUDA stream synchronize
	CudaStreamSyn(chain);

	/* reset m->lnLike using data calculated by GPU and calculate chainLnLike */
	for (d = 0; d < numCurrentDivisions; d++)
	{
		m = &modelSettings[d];
		if (m->upDateCl == YES)
			m->lnLike[2 * chain + state[chain]] = modelLnL_Global[chain * numCurrentDivisions + d] ;//redo
		chainLnLike += m->lnLike[2 * chain + state[chain]];
	}

	return chainLnLike;
}


extern "C" MrBFlt LogLike_CUDA(int chain)
{
	int             i, d;
	ModelInfo       *m;
	MrBFlt          chainLnLike;

	/* initialize chain cond like */
	chainLnLike = 0.0;

	if (chainParams.runWithData == NO)
		return (chainLnLike);

#   if defined (DEBUG_RUN_WITHOUT_DATA)
	return (chainLnLike);
#   endif

	LaunchLogLike_TiProbs(chain);

	//LaunchLogLike_CondLike(chain, & (m->lnLike[2 * chain + state[chain]]));
	LaunchLogLike_CondLike(chain);

	chainLnLike = LaunchLogLike_LnLike(chain);

	return chainLnLike;
}





