#ifndef _KERNEL_H
#define _KERNEL_H

#include <stdio.h>
#include "bayes.h"

#define LIKE_EPSILON        1.0e-300

//#ifdef MPI_ENABLED
//extern int proc_id;
//#endif


/* define structure for CUDA parameters */
template<int nChild> struct CondLike_Input
{
	const CLFlt* cl[nChild];
	const CLFlt* ti[nChild];
};

struct LikelihoodInput
{
	const CLFlt* clP;
	const CLFlt* lnScaler;
	const CLFlt* nSitesOfPat;
	const MrBFlt* bs;
};

struct ModelParam
{
	int numChars;
	int numReps; //Gen: numGammaCats, NY98: numOmegaCats
	int numModelStates;
};



void TransformCondLikes(CLFlt* in, ModelParam m);

template<int nchild> void Launch_Kernel_CondLike_Gen(CondLike_Input<nchild> in, CLFlt* clP, ModelParam m, int chain);
void Launch_Kernel_Scaler_Gen(CLFlt* clP, CLFlt* scP, CLFlt* lnScaler, ModelParam m, int chain);
void Launch_Kernel_Likelihood_Gen(LikelihoodInput in, const CLFlt* clInvar, MrBFlt pInvar, MrBFlt* lnlike, MrBFlt* sum, ModelParam m, int chain);
void Launch_Kernel_Likelihood_NY98(LikelihoodInput in, const MrBFlt* omegaCatFreq, MrBFlt* lnlike, MrBFlt* sum, ModelParam m, int chain);

void Launch_Kernel_CondLike_Gen_2(CLFlt** cl, CLFlt** ti, CLFlt* clP, ModelParam m, int chain);
void Launch_Kernel_CondLike_Gen_3(CLFlt** cl, CLFlt** ti, CLFlt* clP, ModelParam m, int chain);


void SetCudaEnvironment();
void CudaFreeAll();
void CudaMallocAll();
void CudaStreamSyn(int chain);
void cudaMemcpyAsyncModelLnL(int chain);
void cudaMemcpyAsyncTiProbs(TreeNode *p, int division, int chain);
void cudaResetSiteScalers(int division, ModelInfo *m, int chain);
void cudaCopySiteScalers(int division, ModelInfo *m, int chain);
void cudaRemoveNodeScalers(TreeNode *p, int division, int chain);

void CudaMemcpyBS(MrBFlt *bs, int nStates);
void CudaFreeBS();
void CudaMemcpyOmegaCatFreq(MrBFlt *omegaCatFreq, int numOmegaCats);
void CudaFreeOmegaCatFreq();

/* for test and debug */
void cudaMemcpyAsyncLnLike(int chain);
void cudaMemcpyCondLike();




#endif  /* _KERNEL_H*/
